<template>
    <div>
        <el-container>
            <el-header class="inside-header">
                <div>
                    <!-- 面包屑 -->
                    <el-breadcrumb separator=">">
                        <el-breadcrumb-item>企业环保</el-breadcrumb-item>
                        <el-breadcrumb-item>供应商管理</el-breadcrumb-item>
                        <el-breadcrumb-item class="breadcrumbColor">供应商分类</el-breadcrumb-item>
                    </el-breadcrumb>
                </div>
            </el-header>
            <el-main>
                <div class="inside-main-box">
                    <el-row class="inside-main" style="background: #fff;padding-top: 10px;height: 46px;">
                        <el-col :span="8">
                            <el-form-item label="分类名称" size="small">
                                <el-input v-model="form.num" />
                            </el-form-item>
                        </el-col>
                        <el-col :span="4" style="margin-left: 20px;">
                            <el-button size="small" class="sele-but">查询</el-button>
                            <el-button size="small" :icon="Plus" class="add-but" @click="centerDialogVisible = true">新增</el-button>
                        </el-col>
                    </el-row>
                </div>
                <div style="background: #fff;">
                    <el-table :data="tableData" style="width: 100vw;">
                        <el-table-column prop="序号" label="序号" width="50" />
                        <el-table-column prop="分类名称" label="分类名称" width="100" />
                        <el-table-column prop="父级分类" label="父级分类" width="100" />
                        <el-table-column prop="深度" label="深度" width="100" />
                        <el-table-column prop="描述" label="描述" width="100" />
                        <el-table-column prop="创建人" label="创建人" width="100" />
                        <el-table-column prop="创建时间" label="创建时间" width="100" />
                        <el-table-column label="操作" width="120">
                            <template #default>
                                <el-button link type="primary" size="small">修改</el-button>
                                <el-button link type="primary" size="small">删除</el-button>
                            </template>
</el-table-column>
</el-table>
<el-pagination style="margin-top: 20%;display: flex;justify-content: flex-end;" v-model:current-page="currentPage3" v-model:page-size="pageSize3" :small="small" :disabled="disabled" :background="background" layout="prev, pager, next, jumper" :total="1000"
    @size-change="handleSizeChange" @current-change="handleCurrentChange" />
</div>
</el-main>
</el-container>
<!-- 新增弹窗 -->
<el-dialog v-model="centerDialogVisible" title="新增分类" width="40%">
    <div style="width:80%">
        <el-form ref="ruleFormRef" :model="ruleForm" status-icon :rules="rules" label-width="80px" class="demo-ruleForm">
            <el-form-item label="分类名称" prop="username">
                <el-input v-model="ruleForm.username" placeholder="请输入" autocomplete="off" />
            </el-form-item>
            <el-form-item label="选择上级" prop="region">
                <el-select v-model="ruleForm.region" placeholder="请选择">
                    <el-option label="Zone one" value="shanghai" />
                    <el-option label="Zone two" value="beijing" />
                </el-select>
            </el-form-item>
            <el-form-item label="描述" prop="desc">
                <el-input v-model="ruleForm.desc" maxlength="500" placeholder="请输入" show-word-limit type="textarea" />
            </el-form-item>
        </el-form>
    </div>
    <template #footer>
                <span class="dialog-footer">
                    <el-button class="sele-but" @click="centerDialogVisible = false">
                        确定
                    </el-button>
                    <el-button class="empty-but" @click="centerDialogVisible = false">取消</el-button>

                </span>
            </template>
</el-dialog>
</div>
</template>

<script setup lang="ts">
    import {
        reactive,
        ref
    } from 'vue'
    import {
        Plus
    } from "@element-plus/icons-vue";
    // 路由
    import {
        useRouter
    } from 'vue-router'
    import {
        FormInstance,
        FormRules
    } from 'element-plus'
    // 新增弹窗 表单校验
    const ruleForm = reactive({
        username: '',
        region: '',
        desc: ''
    })
    const rules = {
        username: [{
            required: true,
            message: "请输入分类名称",
            trigger: "blur",
        }, {
            // min: 3,
            // max: 10,
            message: "请输入分类名称",
            trigger: "blur",
        }, ],
        region: [{
            required: true,
            message: '请选择上级',
            trigger: 'change',
        }, ],
    };
    const router = useRouter()
        // 新增弹窗
    const centerDialogVisible = ref(false)

    const name = 'transportIndex'
        // 时间
    const size = ref("default");
    const form = reactive({
        num: "",

    });
    // 表格假数据
    const tableData = [{
        序号: "1",
        分类名称: "日常检测",
        父级分类: "-",
        深度: "1",
        描述: "",
        创建人: "",
        创建时间: "",
    }, {
        序号: "2",
        分类名称: "土壤",
        父级分类: "日常检测",
        深度: "2",
        描述: "",
        创建人: "",
        创建时间: "",
    }, ];
</script>
<style scoped>
    /* 面包屑字体颜色更改 */
    
    .breadcrumbColor>>>.el-breadcrumb__inner {
        color: #000;
    }
    /* 内部header */
    
    .inside-header {
        height: 10px;
        display: flex;
        justify-content: left;
        align-items: center;
    }
    /* 空心按钮样式 */
    
    .empty-but {
        border: 1px solid #3780b9;
        color: #3780b9;
    }
    /* 实心按钮背景样式 */
    
    .sele-but {
        background: #3780b9;
        border: 0px;
        border-radius: 2px;
        color: white;
    }
    
    .add-but {
        background: #dde5fe;
        color: #3780b9;
    }
    /* 分页 */
    
    .demo-pagination-block {
        display: flex;
        justify-content: flex-end;
        align-items: center;
    }
</style>