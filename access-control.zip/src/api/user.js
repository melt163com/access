/*
 * @Description: 接口定义
 * @Autor: LiuGang
 * @Date: 2022-04-14 09:25:52
 * @LastEditors: LiuGang
 * @LastEditTime: 2022-12-27 16:27:54
 */
import request from '@/utils/request'

// 查询用户列表
export function getUsers(query,page) {
  return request({
    url: '/backend/admin/buser/getData',
    method: 'post',
    data: query,
    params:page,
  })
}
